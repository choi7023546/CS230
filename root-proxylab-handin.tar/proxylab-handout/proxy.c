#include <stdio.h>
#include "csapp.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

pthread_rwlock_t lock;

/* You won't lose style points for including this long line in your code */
//static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\n";
static const char *connection_hdr = "Connection : close";
static const char *proxy_connection_hdr = "Proxy-Connection: close";

int parse_uri(char *uri, char *host, char *path, int *port);


void close_wrapper(int fd) {
    if (close(fd) < 0)
        printf("Error closing file.\n");
}

/*
 * parse_uri - URI parser
 * 
 * Given a URI from an HTTP proxy GET request (i.e., a URL), extract
 * the host name, path name, and port.  The memory for hostname and
 * pathname must already be allocated and should be at least MAXLINE
 * bytes. Return -1 if there are any problems.
 */
int parse_uri(char *uri, char *hostname, char *pathname, int *port)
{
    char *hostbegin;
    char *hostend;
    char *pathbegin;
    int len;

    if (strncasecmp(uri, "http://", 7) != 0) {
    hostname[0] = '\0';
    return -1;
    }
       
    /* Extract the host name */
    hostbegin = uri + 7;
    hostend = strpbrk(hostbegin, " :/\r\n\0");
    len = hostend - hostbegin;
    strncpy(hostname, hostbegin, len);
    hostname[len] = '\0';
    
    /* Extract the port number */
    *port = 80; /* default */
    if (*hostend == ':')   
    *port = atoi(hostend + 1);
    
    /* Extract the path */
    pathbegin = strchr(hostbegin, '/');
    if (pathbegin == NULL) {
    pathname[0] = '\0';
    }
    else {
    pathbegin++;    
    strcpy(pathname, pathbegin);
    }

    return 0;
}

void convert_request (char *new_buf, char *host, char *port, char *path)
{
    sprintf(new_buf, "GET /%s HTTP/1.0\nHost: %s:%s\n%s\n%s\n\r\n",
            path, host, port, connection_hdr, proxy_connection_hdr);
}

void handle_connection(int *connfdp) {
    printf("\nNow let's handle the connection\n");

    int connfd = *connfdp;
    int port;
    char buf_request[MAXBUF], buf_request_new[MAXBUF], method[MAXLINE], uri[MAXLINE], version[MAXLINE], host[MAXLINE], path[MAXLINE];
    rio_t rio, rio_out;

    // read request from client
    Rio_readinitb(&rio, connfd);
    Rio_readlineb(&rio, buf_request, MAXBUF);
    sscanf(buf_request, "%s %s %s", method, uri, version);
    parse_uri(uri, host, path, &port);
    printf("whole request is:\n%s\n", buf_request);
    printf("method: %s\nuri: %s\nversion: %s\nhost: %s\npath: %s\nport: %d\n\n", method, uri, version, host, path, port);

   
    char port_str[20];
    sprintf(port_str, "%d", port); // cast port to str

    // convert to HTTP 1.0 request from buf_request to buf_request_new
    convert_request (buf_request_new, host, port_str, path);
    printf("converted request is:\n%s\n\n", buf_request_new);
 
    // open new connection from proxy to server
    int out_connfd = Open_clientfd(host, port_str);

    // write request to server
    Rio_readinitb(&rio_out, out_connfd);
    Rio_writen(out_connfd, buf_request_new, MAXBUF);
    printf("Now request is forwarded to server!\n");
    
    int n;
    memset(buf_request, 0, MAXBUF);
    printf("buffer should be cleared %s\n", buf_request); //should be 0
    while ((n = Rio_readnb(&rio_out, buf_request, MAXBUF)) > 0) {
        printf("while-loop\n");
        Rio_writen(connfd, buf_request, n);
    }
    printf("reponse forwarded\n");

    Close(out_connfd);
}

int main(int argc, char *argv[])
{
    int listenfd, *connfdp;
    socklen_t clientlen;
    struct sockaddr_in clientaddr;
    char clienthost[MAXLINE];
    char clientport[MAXLINE];
    
    // ignore sigpipes
    signal(SIGPIPE, SIG_IGN);

    // initialize reader/writer lock for cache
    pthread_rwlock_init(&lock, NULL);

    // establish client port (default: 29094)
    if (!argv[1]){
        printf("Missing command line port number\n");
        return -1;
    }

    // establish listening file
    listenfd = open_listenfd(argv[1]);
    clientlen = sizeof(clientaddr);

    if (listenfd < 0)
        printf("open_listenfd failed.\n");
    else {
        printf("open_listenfd %d success.\n", listenfd);
        while (1) {
            // when a client connects, spawn a new thread to handle it.
            connfdp = Malloc(sizeof(int));
            *connfdp = accept(listenfd, (struct sockaddr *)&clientaddr, &clientlen);
            if (connfdp < 0) {
                printf("Accept failed.\n");
                Free(connfdp);
            }
            else {
                // do something
                printf("Accept succeeded.\n");
                // referenced from lecture slide
                Getnameinfo((const struct sockaddr *)&clientaddr, clientlen,
                            clienthost, MAXLINE, clientport, MAXLINE, 0);
                printf("client address/port is %s/%s, connected to %d\n", clienthost, clientport, *connfdp);
                handle_connection(connfdp);
                Close(*connfdp);
                Free(connfdp);
            }
        }
    }
    close_wrapper(listenfd);
    pthread_rwlock_destroy(&lock);
    return 0;
}
